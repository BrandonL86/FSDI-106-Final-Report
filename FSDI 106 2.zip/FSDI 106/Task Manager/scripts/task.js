

class Task{

   constructor(important, title, description, duedate, status, budget, color){
    this.important = important
    this.title = title;
    this.description = description;
    this.duedate = duedate;
    this.status = status;
    this.budget = budget;
    this.color = color;


    this.name = "Brandon";
   } 
}
