
let isImportant = false;
let isVisible = true;

//toggleImportant

function toggleImportant(){
    const nonImportantIcon = "fa-regular fa-star";
    const importantIcon = "fa-solid fa-star";


    if(!isImportant){
        $("#iImportant").removeClass(nonImportantIcon).addClass(importantIcon);
        isImportant = true;
        console.log("This task was labeled as Important");
    }
    else{
        $("#iImportant").removeClass(importantIcon).addClass(nonImportantIcon);
        isImportant = false;
        console.log("This Task was labeled not Important");
    }
}

function hideDetails(){

    $(".Task").hide();
    console.log("Details Hidden");

    if(!isVisible){
        $(".Task").show();
        isVisible = true;
    }
    else{
        $(".Task").hide();
        isVisible = false;
    }
}



 async function saveTask(){
    console.log("saving Task...");

   let title = $("#txtTitle").val();
   let description = $("#txtDescription").val();
   let duedate = $("#dueDate").val();
   let status = $("#selStatus").val();
   let budget = $("#txtBudget").val();
   let color = $("#selColor").val();

   console.log(title, description, duedate, status, budget, color);


   let taskToSave = new Task(isImportant, title, description, duedate, status, budget, color);

      //send task to the server
      let response = await fetch("https://fsdiapi.azurewebsites.net/api/tasks/",{
        method: "POST",
        body:JSON.stringify(taskToSave),
        headers:{
            "Content-type": "application/json"
        }
      });

      if(response.ok){
        displayTask(taskToSave);
        clearForm();

        //get data from the response
        let data = await response.json();
        console.log(data);
      }
      else{
        alert("Error saving tasks, please try again.");
      }
}

function displayTask(task){
    let syntax = `
    <div class ="Task" style="border-color:${task.color}">
    <div class = "Details">
    <h5>${task.title}</h5>
    <p>${task.description}</p>
    </div>


    <label>${task.duedate}</label>
    <label>${task.budget}</label>
    <label>${task.status}</label>
    </div>`;
    
    

    $("#pending-tasks").append(syntax);


}

function clearForm(){

}

async function testRequest() {
   let response = await fetch("https://fsdiapi.azurewebsites.net/api/tasks/");
   console.log(response);
}

 async function loadTasks(){
    //get https://fsdiapi.azurewebsites.net/api/tasks/
    // console log the data from the response

    let response = await fetch("https://fsdiapi.azurewebsites.net/api/tasks/")
    if (response.ok) {
        let data = await response.json();

        for (let i = 0; i < data.length; i++) {
            let task = data[i];
            if(task.name == "Brandon"){
                displayTask(task);

            }
        }
        //travel data with a for loop
        //get every task from the array
        //send the task to displayTask function
        console.log(data);

    }
    else{
        alert("Error loading tasks!");
    }
}

async function deleteAll(){
    let response = await fetch("https://fsdiapi.azurewebsites.net/api/tasks/clear/Brandon/", {
        method: "DELETE"
    });

    if(response.ok) {
        //remove all task from the screen
        $(".task").remove();

    }
    else {
        alert("Error delete your tasks");
    }

}

function init(){
    console.log("Task Manager");

    //load data
    loadTasks();

    // catch/hook events
    $("#btnSave").click(saveTask);
    $("#iImportant").click(toggleImportant);
    $("#hideTask").click(hideDetails);
    $("#btnDelete").click(deleteAll);
}



window.onload = init;

// Suggestion Read:
//How to create an object in JS -> object Literal, Obj construction, classes

