

function sayHello(name){
    console.log("Hello" + name);
}

function sum(num1, num2){
    let total = num1 + num2;
    return total;
}

function printNumbers(){
    for(let i=1; i < 21; i++) {
        if(i != 7 && i != 13) {
            
            console.log(i);

        }
    }

    let color= "red";
    let age = 0;

    if(!color) {
        alert("Error: a color is needed");
    }

    if (!age){
        alert("Error: age is required");
    }

}

function init(){
// all HTML elements are rendered
console.log("Task Manager");

sayHello("John");
sayHello("Jane");

let name ="Sergio";
sayHello(name);
sayHello("Name");

let last = "Rogers";
sayHello(last);

printNumbers();

}

// sum
let total = sum(21,21);
console.log(total);


window.onload = init;